/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "io_unity_c_export.h"
#include "BKE_context.h"
#include "BKE_mesh.h"
#include "DEG_depsgraph.h"
#include "DNA_object_types.h"
#include "BLI_fileops.h"
#include "BLI_math.h"
#include "BLI_string.h"
#include "BLI_utildefines.h"
#include <stdio.h>

static bool write_u32(FILE *f, unsigned int v) { return fwrite(&v, 4, 1, f) == 1; }
static bool write_f32(FILE *f, float v) { return fwrite(&v, 4, 1, f) == 1; }

bool UNITYC_export_scene(bContext *C, const UnityCExportParams *params)
{
  if (!params || params->filepath[0] == '\0') return false;
  FILE *f = BLI_fopen(params->filepath, "wb");
  if (!f) return false;
  fwrite("UMSH", 1, 4, f);
  write_u32(f, 1);
  write_f32(f, params->global_scale);
  write_u32(f, 0); /* mesh count dummy */
  fclose(f);
  return true;
}
