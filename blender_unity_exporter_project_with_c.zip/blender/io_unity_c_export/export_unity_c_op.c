/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "io_unity_c_export.h"
#include "BKE_context.h"
#include "WM_api.h"
#include "WM_types.h"
#include "RNA_access.h"
#include "RNA_define.h"
#include "MEM_guardedalloc.h"

typedef struct ExportUnityCOp {
  UnityCExportParams params;
} ExportUnityCOp;

static bool export_unity_c_exec(bContext *C, wmOperator *op)
{
  ExportUnityCOp *eu = op->customdata;
  RNA_string_get(op->ptr, "filepath", eu->params.filepath);
  eu->params.global_scale = RNA_float_get(op->ptr, "global_scale");
  if (!UNITYC_export_scene(C, &eu->params)) {
    return OPERATOR_CANCELLED;
  }
  return OPERATOR_FINISHED;
}

void EXPORT_OT_unity_c(wmOperatorType *ot)
{
  ot->name = "Unity C Export (.umesh)";
  ot->idname = "EXPORT_SCENE_unity_c";
  ot->exec = export_unity_c_exec;
  ot->flag = OPTYPE_REGISTER | OPTYPE_PRESET;
  RNA_def_string_file_path(ot->srna, "filepath", NULL, 0, "File Path", "Output .umesh file");
  RNA_def_float(ot->srna, "global_scale", 1.0f, 0.0001f, 1000.0f, "Scale", "", 0.01f, 100.0f);
}
